class Design
{
    void display_design()throws Exception
    {
        System.out.println("\t\t\t === |  | |\\  |  ===  |  /  ====   ====  |   ");
        System.out.println("\t\t\t|__  |  | | \\ | |___  |-   |    | |    | |   ");
        System.out.println("\t\t\t|    |__| |  \\|  ___| |  \\ |____| |____| |___");
        System.out.println();
        System.out.println("\t\t\t                                            PRESENTS");
        Thread.sleep(4000);
        System.out.println("======= |    |  =====     ======      /\\     |\\    /|  =====     =====   =====    |      == ==  =====  =====");
        System.out.println("   |    |    | |         |           /  \\    | \\  / | |         |     | |         |        |   |      |     ");
        System.out.println("   |    |====| |___      |   ___    /____\\   |  \\/  | |___      |     | |___      |        |   |___   |___  ");
        System.out.println("   |    |    | |         |      |  /      \\  |      | |         |     | |         |        |   |      |     ");
        System.out.println("   |    |    | |_____    |______| /        \\ |      | |_____    |_____| |         |_____ __|__ |      |_____");
        Thread.sleep(5000);
        System.out.print("\u000C");
    }
}