class Display
{
    void display()throws Exception
    {
        System.out.println("\t* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
        System.out.println("\t*|\\    /|     /\\     ======= |    |   ===== |\\    /|     /\\     ======= =======  =====  ===== *");
        System.out.println("\t*| \\  / |    /  \\       |    |    |  |      | \\  / |    /  \\       |       |    |      |      *");
        System.out.println("\t*|  \\/  |   /____\\      |    |----|  |___   |  \\/  |   /____\\      |       |    |      |_____ *");
        System.out.println("\t*|      |  /      \\     |    |    |  |      |      |  /      \\     |       |    |            |*");
        System.out.println("\t*|      | /        \\    |    |    |  |_____ |      | /        \\    |    ___|___ |_____  _____|*");
        System.out.println("\t*                                                                                             *");
        System.out.println("\t*                       =====  |     |  =====  =====  |       =====  =====                    *");
        System.out.println("\t*                      |     | |     |     /      /   |      |      |                         *");
        System.out.println("\t*                      |_____| |     |    /      /    |      |___   |_____                    *");
        System.out.println("\t*                      |       |     |   /      /     |      |            |                   *");
        System.out.println("\t*                      |       |_____|  /____  /____  |_____ |_____  _____|                   *");
        System.out.println("\t* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
        Thread.sleep(5000);
        System.out.print("\u000C");
    }
}